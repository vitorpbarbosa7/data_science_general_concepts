# Funções para criar dados para conjuntos de dados,vetores,colunas,etc
?rep
rep("abc",3) # repete abc 3 vezes

rep(c("a","b","c"),times=3) # 3 vezes a b c
rep(c("a","b","c"),each=3)# a 3x, b 3x, c 3x

rep(c("a","b","c"),each=3,times=2) #(a 3x, b 3x, c 3x) 2x

?sample # amostra
sample(1:10,5,replace=T) # 5 valores entre 1 e 10

sample(1:5,10,replace=T) # 10 valores entre 1 e 5

?set.seed
set.seed(11) # valor para controlar aleatoriedade

#criar data frame
x<- data.frame("a"= 1:5, "b"= c("a","b","c","d","e"))


dados1<- data.frame("genero" =  c(rep("masculino",12),rep("feminino",14)),
                                  "altura"= sample(150:172,26,replace=TRUE)/100,
                                  "peso"= sample(60:75,26,replace=TRUE),
                                  "nota" = sample(4:10,26,replace=TRUE),
                                  "lateralidade"= sample(c("canhoto","destro"),26,replace=TRUE,prob= c(0.8,0.2))
                    )
                    

write.csv(dados1,"dados1.csv") # salvar

#criando colunas

dados1$cor_favorita<- sample(c("azul","vermelho","verde","amarelo"),26,replace=T)

dados1$imc<- dados1$peso / dados1$altura^2  #índice de massa corporea (bmi)



