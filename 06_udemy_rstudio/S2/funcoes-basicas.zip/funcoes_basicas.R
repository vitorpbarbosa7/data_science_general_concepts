#Vetor
#sequência de elementos do mesmo tipo
#uma dimensão

x<- c(1,3,5,6,8)

m = 2:20

#operações com vetores
x+2

x/2

x * 2

m + 3

#média
mean(x)
mean(m)

#mediana
median(x)
median(m)

#soma
sum(x)
sum(m)

#desvio padrão
sd(x)


#boxplot
boxplot(x)
boxplot(m)
