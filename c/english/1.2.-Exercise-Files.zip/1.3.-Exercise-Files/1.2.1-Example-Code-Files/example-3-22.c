#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

   int name[100] = {0};
   int name2[100] = {0};

   if (name == name2)
   {
        printf("Name\n" );
       return 0;
   }
   return 0;
}
