#include <stdio.h>

int main()
{
    int num_of_apples;

	num_of_apples = 80;

	//int num_of_apples = 80;

    printf("the variable num_of_apples holds the value %d\n", num_of_apples);

    return 0;
}
