#ajuda dentro do R

help.start() #ajuda geral do R

help("*")

help(mean)

help.search("mean")


?sd #mesmo que help
??sd #mesmo que help.search

apropos("help") #funções contendo "help"
apropos("mean")

#exemplos de uso
example(mean)# exemplo de uso

example(plot)

